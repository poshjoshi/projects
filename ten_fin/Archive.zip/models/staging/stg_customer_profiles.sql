{{
    config(
        alias = 'stg_customer_profiles',
    )
}}

WITH source_data AS (

    SELECT

        /* Considered removing the cases where no email is generated but we should highlight issues with data quality
         * rather then ignore/remove them.
         */
        CASE
            WHEN email IS NOT NULL THEN MD5(LOWER(email))
        END AS user_id
        , LOWER(email) AS email
        , name
        , country
        , CASE allow_email_tracking
            WHEN 'yes' THEN TRUE
            WHEN 'no' THEN FALSE
            -- Where none provided be defensive and assume FALSE.
            ELSE FALSE
        END AS allow_email_tracking
        , modified_at
        /* Would use below for partitioning strategy but lack of partitions in duckDB :sob
         * also partitioning on such a small data set would be a little bit silly.
         */
        , STRFTIME(modified_at, '%Y-%m-%d') AS modified_date

    FROM {{ source("main", "customer_profiles") }}

)

SELECT *
FROM source_data