{{
    config(
        alias = 'stg_email_activity',
    )
}}

WITH source_data AS (

    SELECT

        /* Considered removing the cases where no email is generated but we should highlight issues with data quality
         * rather then ignore/remove them - there is an upstream issue if we are generating events without emails and
         * it should be fixed.
         */
        CASE
            WHEN email IS NOT NULL THEN MD5(LOWER(email))
        END AS user_id
        , LOWER(email) AS email
        , event
        , event_time
        /* Would use below for partitioning strategy but lack of partitions in duckDB :sob
         * also partitioning on such a small data set would be a little bit silly.
         */
        , STRFTIME(event_time, '%Y-%m-%d') AS event_date

    FROM {{ source("main", "email_activity") }}

)

SELECT *
FROM source_data