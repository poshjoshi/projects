{{
    config(
        alias = 'customers_daily',
    )
}}

WITH mocked_created_users AS (

    /* As we have events from when before the customer has a modified date I'm going to assume the first row for the customer
    * is the first date and populated it with a modified at from when the first ever event is generated.
    * making the assumption that the first modified at date for a customer would be the created at.
    * 
    * I've also noticed that there is only one row per email in the customer profile data but I'm going to build it in a way
    * that allows updates to the users profile i.e. do they suddenly switch of user tracking or change their name.
    */

    SELECT

        user_id
        , email
        , name
        , country
        , allow_email_tracking
        , TIMESTAMP '2023-01-01 00:00:01' AS modified_at
        , DATE '2023-01-01' AS modified_date
        

    FROM {{ ref("stg_customer_profiles") }}
    QUALIFY ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY modified_at) = 1

)

, date_spine AS (

	-- Generate a date spine from the first email event (which is also the artificial creation date of customers.)
	SELECT CAST(RANGE AS DATE) AS grid_date
	FROM RANGE(DATE '2023-01-01', CURRENT_DATE(), INTERVAL 1 DAY)

)

, user_day_grid AS (

    SELECT

        mocked_created_users.user_id
        , date_spine.grid_date

    FROM mocked_created_users
        CROSS JOIN date_spine

)

, mocked_users_with_actual_user_data AS (

    /* Although this will actually lead to no actual change in the final output is generated because the values against the
    * customer don't change so when this pulls into the gapless table it will just be taking values which are the same
    * as the values from previous days - I'm building it where I'm imagining they can change.
    * 
    * In the real world this would just be once table where it contains a full history of user updates.
    * 
    * I know this looks super weird but the benefity will be visible when performing analytics on the final mart.
    */

    SELECT *
    FROM mocked_created_users
    UNION ALL
    SELECT *
    FROM {{ ref("stg_customer_profiles") }}

)

, emails_daily AS (


    -- Aggregate up the counts for the emails events for each user for each day.

    SELECT

        user_id
        , event_date
        , SUM(CASE WHEN event = 'delivered' THEN 1 ELSE 0 END) AS total_delivered
        , SUM(CASE WHEN event = 'bounced' THEN 1 ELSE 0 END) AS total_bounced
        , SUM(CASE WHEN event = 'open' THEN 1 ELSE 0 END) AS total_open

    FROM {{ ref("stg_email_activity") }}

    WHERE user_id IS NOT NULL

    GROUP BY 1, 2

)

, users_daily AS (

    SELECT

        user_day_grid.user_id || user_day_grid.grid_date AS surrogate_key
        , user_day_grid.user_id
        , user_day_grid.grid_date
        , LAST_VALUE(email IGNORE NULLS) OVER (PARTITION BY user_day_grid.user_id ORDER BY user_day_grid.grid_date) AS email
        , LAST_VALUE(name IGNORE NULLS) OVER (PARTITION BY user_day_grid.user_id ORDER BY user_day_grid.grid_date) AS name
        , LAST_VALUE(country IGNORE NULLS) OVER (PARTITION BY user_day_grid.user_id ORDER BY user_day_grid.grid_date) AS country
        , LAST_VALUE(allow_email_tracking IGNORE NULLS) OVER (PARTITION BY user_day_grid.user_id ORDER BY user_day_grid.grid_date) AS allow_email_tracking
        , COALESCE(total_delivered) AS total_delivered
        , COALESCE(total_bounced) AS total_bounced
        , COALESCE(total_open) AS total_open

    FROM user_day_grid
        LEFT JOIN mocked_users_with_actual_user_data
            ON user_day_grid.user_id = mocked_users_with_actual_user_data.user_id
                AND user_day_grid.grid_date = mocked_users_with_actual_user_data.modified_date
        LEFT JOIN emails_daily
            ON user_day_grid.user_id = emails_daily.user_id
                AND user_day_grid.grid_date = emails_daily.event_date

    /* I don't actually need this qualify because there isn't duplicates on the same day and also I'd have to probably put this qualify first
    * and then the LAST_VALUE functions in a separate CTE, also something else very weird is that duckDB didn't seem to allow me to build the WINDOW
    * and then just call it with the aggregate functions - one to figure out.
    */
    QUALIFY ROW_NUMBER() OVER (PARTITION BY user_day_grid.user_id, user_day_grid.grid_date ORDER BY mocked_users_with_actual_user_data.modified_at DESC) = 1

)

SELECT *
FROM users_daily
